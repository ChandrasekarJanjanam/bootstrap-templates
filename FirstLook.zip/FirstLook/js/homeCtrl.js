/**
 * Controls Overview Page
 */  
jobscoutApp.controller('homeCtrl', function ($scope, $http, $location, RefDataService) {
	console.log("homeCtrl Controller reporting for duty.");
		
	// Get City list from backend service
	$http.get("json/cities.json").success(function (resp){
		$scope.cities = resp;
		$scope.city = resp[0];
		console.log("in page "+cities.length);
	}),
	function(error){
		alert ("error"+error);
	}
	
	// Get Jobs list from backend service
	$http.get("json/jobs.json").success(function (resp){
		$scope.jobs = resp;
		console.log("in page "+resp[0]);
		//$scope.cityObj = $scope.cities[0];
	}),
	function(error){
		alert ("error"+error);
	}
	
	// Get area list for given cityId
	$scope.getAreasForCity = function(cityId){
		console.log("cityid "+cityId);
		var url = "";
		if(cityId == 1){
			url = "json/hyderabad.json";
		}else{
			url = "json/guntur.json";
		}
		
		// Make ajax call to get list of areas
		RefDataService.getAjaxData(url).then(function (result) {
			$scope.getAjaxData = result.data;     
			areas = result.data;			
			//console.log("in page "+areas[0]);
			$scope.areas =  areas;
			//$scope.areas={};
		}, function (result) {
			alert("Error: No data returned");
		});
	}
	
	$scope.searchCandidates = function(){
		//console.log("inside");
		console.log("city id-->"+$scope.cityId +" job id-->"+$scope.selectedCandidate.originalObject.jobId+" area id-->"+$scope.selectedArea.originalObject.areaId);
		/*CandidateListService.getCandidateList($scope.cityId).then(function (result) {
			$scope.$on('handlebroadcast', function(){
			$scope.cityId = 'one '+CandidateListService.mesg;
			});
			$location.path("/searchCandidates");
		}, function (result) {
			alert("Error: No data returned");
		});*/
		
		
	}
    
	
   
});




/******** Auto complete starts ************/
// https://jsfiddle.net/gumarelo/3qowzjv8/

/*********** select dropdown - start *********************/

// Ref link : http://jsfiddle.net/9Ymvt/880/
