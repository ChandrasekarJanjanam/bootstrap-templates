/**
 * Main AngularJS Web Application
 */
var firstLookApp = angular.module('firstLookApp', ['ngRoute', 'angucomplete-alt']);

var cities = new Array();
/**
 * Configure the Routes
 */
firstLookApp.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
	.when("/overview", {templateUrl: "partials/overview.html", controller: "PageCtrl"})
    .when("/onboarding", {templateUrl: "partials/onboarding.html", controller: "PageCtrl"})
    .when("/bigpicture", {templateUrl: "partials/services.html", controller: "PageCtrl"})
    .when("/db/schema", {templateUrl: "partials/packages.html", controller: "PageCtrl"})
    .when("/db/query", {templateUrl: "partials/contact.html", controller: "PageCtrl"})
    // Workspace
    .when("/workspace/los", {templateUrl: "partials/blog.html", controller: "BlogCtrl"})
    .when("/workspace/bpm", {templateUrl: "partials/blog_item.html", controller: "BlogCtrl"})
	.when("/workspace/tally", {templateUrl: "partials/blog_item.html", controller: "BlogCtrl"})
	// ESB
	.when("/ESB", {templateUrl: "partials/searchCandidates.html", controller: "PageCtrl"})
    .when("/ESB/mockservices", {templateUrl: "partials/faq.html", controller: "PageCtrl"})
    //EJB
	.when("/EJB", {templateUrl: "partials/services.html", controller: "PageCtrl"})
	.when("/EJB/test", {templateUrl: "partials/services.html", controller: "PageCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);

/**
 * Controls the Blog
 */
firstLookApp.controller('BlogCtrl', function (/* $scope, $location, $http */) {
  console.log("Blog Controller reporting for duty.");
});

/**
 * Controls all other Pages
 */
firstLookApp.controller('PageCtrl', function ($scope, $location, $http) {
	console.log("Page Controller reporting for duty.");
	
});

