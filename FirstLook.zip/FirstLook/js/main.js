
/**
 * Main AngularJS Web Application
 */
var app = angular.module('tutorialWebApp', ['ngRoute','ui.bootstrap','ngTouch', 'angucomplete-alt']);
var areas = new Array();
/**
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
	.when("/onboarding", {templateUrl: "partials/onboarding.html", controller: "PageCtrl"})
    .when("/overview", {templateUrl: "partials/overview.html", controller: "overViewCtrl"})
	.when("/bigpicture", {templateUrl: "partials/bigpicture.html", controller: "PageCtrl"})
	
	// Workspace
	.when("/workspace/los", {templateUrl: "partials/esb_mockservice.html", controller: "BlogCtrl"})
	.when("/workspace/bpm", {templateUrl: "partials/services.html", controller: "BlogCtrl"})
	.when("/workspace/tally", {templateUrl: "partials/esb_mockservice.html", controller: "BlogCtrl"})
	
	// DB Details
    .when("/db/schema", {templateUrl: "partials/dbschema.html", controller: "PageCtrl"})
    .when("/db/query", {templateUrl: "partials/dbquery.html", controller: "PageCtrl"})
    
    // ESB
    .when("/ESB", {templateUrl: "partials/esb.html", controller: "BlogCtrl"})
    .when("/ESB/mockservices", {templateUrl: "partials/esb_mockservice.html", controller: "BlogCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);

/**
 * Controls the Blog
 */
app.controller('BlogCtrl', function ( $scope, $location, $http ) {
  console.log("Blog Controller reporting for duty.");
});

/**
 * Controls all other Pages
 */  
app.controller('PageCtrl', function ($scope, $location, $http, RefDataService) {
	console.log("Page Controller reporting for duty.");
	
});

/**** Accordion - starts ********/
app.controller('onboardingCtrl', function($scope, $http){
 
    $scope.dishes = new Array();	
	$http.get('json/item-listing.json').success(function(data) {
		$scope.dishes = data;
		for(var i=0; i<$scope.dishes.length;i++){
			$scope.dishes[i].show = false;
		}
	}).error(function(){
	});	
	$scope.status = {
		isFirstOpen: true,
		isFirstDisabled: false
	};
 });
 /**** Accordion - ends ********/
 