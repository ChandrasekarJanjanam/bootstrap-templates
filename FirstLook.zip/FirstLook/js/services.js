firstLookApp.$inject = ['$scope', 'RefDataService', 'CandidateListService'];

firstLookApp.factory('RefDataService', ['$http','$q',  function($http) {
    
       var factory = {
            getAjaxData: function (url) {  
                console.log(url);
                var data = $http({method: 'GET', url: url});          
                return data;
            }
       }       
        return factory;
		
}]);

// pass data between controller
// http://jsfiddle.net/gonzalo123/myc5rcLw/

//http://stackoverflow.com/questions/20181323/passing-data-between-controllers-in-angular-js

firstLookApp.service('CandidateListService', function() {
  var candidateList = [];

  var addCandidateList = function(newObj) {
      //console.log("newObj-->"+newObj);
	  candidateList = newObj;
	  console.log("candidateList-->"+candidateList.length);
	  
  };

  var getCandidates = function(){
      return candidateList;
  };

  return {
    addCandidateList: addCandidateList,
    getCandidates: getCandidates
  };

});