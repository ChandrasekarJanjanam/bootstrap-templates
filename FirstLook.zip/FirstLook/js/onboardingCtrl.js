/**
 * Controls Overview Page
 */  
firstLookApp.controller('onboardingCtrl', function ($scope, $location, $http, CandidateListService, RefDataService) {
	console.log("onboardingCtrl Controller reporting for duty.");
	$scope.list = CandidateListService.getCandidates();
	console.log("getCandidates --> "+CandidateListService.getCandidates().length);
	RefDataService.getAjaxData("json/item-listing.json").then(function (result) {
			$scope.dishes = result.data;			
		}, function (result) {
			alert("Error: No data returned");
		});	
	
});
	