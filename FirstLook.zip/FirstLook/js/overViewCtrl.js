/**
 * Controls Overview Page
 */  
firstLookApp.controller('overViewCtrl', function ($scope, $location, $http, RefDataService, CandidateListService) {
	console.log("overViewCtrl Controller reporting for duty.");
	
	// Get City list from backend service
	$http.get("json/cities.json").success(function (resp){
		$scope.cities = resp;
		//console.log("in page "+resp.length);
		$scope.city = $scope.cities[0];
		
	}),
	function(error){
		alert ("error"+error);
	}
	
	// Get Jobs list from backend service
	$http.get("json/jobs.json").success(function (resp){
		$scope.jobs = resp;
		//console.log("in page "+resp[0]);		
	}),
	function(error){
		alert ("error"+error);
	}
	
	// Get area list for given cityId
	$scope.getAreasForCity = function(cityId){
		console.log("cityid "+cityId);
		var url = "";
		if(cityId == 1){
			url = "json/hyderabad.json";
		}else{
			url = "json/guntur.json";
		}
		
		// Make ajax call to get list of areas
		RefDataService.getAjaxData(url).then(function (result) {
			$scope.getAjaxData = result.data;     
			areas = result.data;						
			$scope.areas =  areas;			
		}, function (result) {
			alert("Error: No data returned");
		});
	}
	
	$scope.searchCandidates = function(){
		
		console.log("city id-->"+$scope.cityId +" job id-->"+$scope.selectedCandidate.originalObject.jobId+" area id-->"+$scope.selectedArea.originalObject.areaId);
		
		RefDataService.getAjaxData("json/categories.json").then(function (result) {
			CandidateListService.addCandidateList(result.data);
			$location.path("/onboarding");
		}, function (result) {
			alert("Error: No data returned");
		});		
	}     
});




/******** Auto complete starts ************/
// https://jsfiddle.net/gumarelo/3qowzjv8/

/*********** select dropdown - start *********************/

// Ref link : http://jsfiddle.net/9Ymvt/880/

