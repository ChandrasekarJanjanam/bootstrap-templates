/**
 * Controls Overview Page
 */  
app.controller('overViewCtrl', function ($scope, $location, $http, RefDataService) {
	console.log("overViewCtrl Controller reporting for duty.");
	
	$scope.scores = [{name:'Cities', URL:'json/cities.json'},
                    {name:'Areas', URL:'json/areas.json'}];
    
    $scope.getScoreData = function(score){
    RefDataService.getScoreData(score.URL).then(function (result) {
			$scope.ScoreData = result.data;     
			areas = result.data;
			console.log("in page "+areas[0]);
			$scope.cities =  areas;
		}, function (result) {
			alert("Error: No data returned");
		});
    };   
});

app.$inject = ['$scope', 'RefDataService'];

app.factory('RefDataService', ['$http','$q',  function($http) {
    
       var factory = {
            getScoreData: function (url) {  
                console.log(url);
                var data = $http({method: 'GET', url: url});          
                return data;
            }
       }       
        return factory;
}]);

