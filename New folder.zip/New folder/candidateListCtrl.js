/**
 * Controls Candidate List Page
 */  
jobscoutApp.controller('candidateListCtrl', function ($scope, $http, $location, CandidateListService) {
	console.log("candidateListCtrl Controller reporting for duty.");
	
	$scope.$on('handlebroadcast', function(){
			$scope.cityId = 'two '+CandidateListService.mesg;
		});
		
	
	
   
});


