jobscoutApp.$inject = ['$scope', 'RefDataService', 'CandidateListService'];
//jobscoutApp.$inject = ['$scope', 'CandidateListService'];

jobscoutApp.factory('RefDataService', ['$http','$q',  function($http) {
    
       var factory = {
            getAjaxData: function (url) {  
                console.log(url);
                var data = $http({method: 'GET', url: url});          
                return data;
            }

       }       
        return factory;
		/*
		var factory1 = {
			getCandidateList:function(cityId){
				console.log("city id in service-->"+cityId);
			}
		}
		return factory1;
		*/
}]);



jobscoutApp.factory('CandidateListService', ['$rootScope',function ($rootScope){
	
		var sharedService = {};
		sharedService.mesg = '';
		sharedService.getCandidateList = function(mesg){
			this.message = mesg;
			this.broadcast();
		};
		
		sharedService.broadcast = function(){
			$rootScope.$broadcast('handlebroadcast');
		};
}]);
