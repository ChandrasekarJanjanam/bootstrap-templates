/**
 * Main AngularJS Web Application
 */
var jobscoutApp = angular.module('jobscoutApp', ['ngRoute', 'angucomplete-alt', 'ui.bootstrap', 'ngTouch']);

var cities = new Array();
/**
 * Configure the Routes
 */
jobscoutApp.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
    .when("/searchCandidates", {templateUrl: "partials/searchCandidates.html", controller: "PageCtrl"})
    .when("/hotpicks", {templateUrl: "partials/faq.html", controller: "PageCtrl"})
    .when("/about", {templateUrl: "partials/services.html", controller: "PageCtrl"})
    .when("/healthpackages", {templateUrl: "partials/packages.html", controller: "PageCtrl"})
    .when("/contact", {templateUrl: "partials/contact.html", controller: "PageCtrl"})
    // Blog
    .when("/blog", {templateUrl: "partials/blog.html", controller: "BlogCtrl"})
    .when("/blog/post", {templateUrl: "partials/blog_item.html", controller: "BlogCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
}]);

/**
 * Controls the Blog
 */
jobscoutApp.controller('BlogCtrl', function (/* $scope, $location, $http */) {
  console.log("Blog Controller reporting for duty.");
});

/**
 * Controls all other Pages
 */
jobscoutApp.controller('PageCtrl', function ($scope, $location) {
	console.log("Page Controller reporting for duty.");
	
});

