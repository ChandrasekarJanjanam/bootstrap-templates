/**
 * Controls Candidate List Page
 */  
jobscoutApp.controller('CandidateController', function ($scope, $location, $http, CandidateService) {
	console.log("CandidateController reporting for duty");
	//$scope.candidateList = CandidateService.getCandidateListFromCache();
	//console.log("getCandidateListFromCache --> "+$scope.candidateList.length);
	
	// candidate default sorting order
	$scope.candidateSort = 'expectedMonthlySalary';
	
	//Slider config with custom display function using html formatting
	$scope.gender = 'M';
	 
	$scope.demo2 = {
    range: {
        min: 0,
        max: 10050
    },
    minPrice: 1000,
    maxPrice: 4000
};
$scope.demo9 = {
    max: 5000,
    min: 3000
};
	
	// temp code to load with dummy data
	var cand = [];
	CandidateService.fetchAllCandidates()
	.then(
			function(result) {				
				cand = result;
				$scope.candidateList = cand;
				console.log("getCandidateListFromCache --> "+$scope.candidateList.length);
				
			},
			function(errResponse){
				alert("Error: No data returned");
			}
		);
});
	


