/**
 * Controls Overview Page
 */  
 var areas = [];
 var jobs = [];
jobscoutApp.controller('HomeController', function ($scope, $http, $location, CityService, AreaService, CandidateService) {
	console.log("homeCtrl Controller reporting for duty.");
		
	// Get City list from backend 
	CityService.fetchAllCities()
	.then(
	   function(resp){
			$scope.cities = resp;
			$scope.city = resp[0];
			console.log("in page "+cities.length);
	    },
		function(errResponse){
			console.error('Error while fetching cities');
		}
	);
		
	// Get City list from backend service
	$http.get("json/hyderabad.json").success(function (resp){
		areas = resp;	
		$scope.areas = resp;
		//$scope.city = resp[0];
		console.log("in page areas "+areas.length);
	}),
	function(error){
		alert ("error"+error);
	}
	
	// Get Jobs list from backend service
	$http.get("json/jobs.json").success(function (resp){
		$scope.jobs = resp;
		jobs = resp;
		console.log("jobs--> "+jobs.length);
		//$scope.cityObj = $scope.cities[0];
	}),
	function(error){
		alert ("error"+error);
	}
	
	// Get area list for given cityId
	$scope.getAreasForCity = function(city){
		console.log("cityid "+city.cityId);
		var url = "";
		if(city.cityId == 1){
			url = "json/hyderabad.json";
		}else{
			url = "json/guntur.json";
		}
		
		// Get areas by city id
		AreaService.getAreasByCityId(city.cityId)
		.then(
			function(result) {				
				areas = result;			
				console.log("in areas "+areas.length);
				$scope.areas =  areas;				
			},
			function(errResponse){
				console.error('Error while fetching areas');
			}
		);		
	}
	
	$scope.getCandidatesByCriteria = function(){		
		console.log("city id-->"+$scope.city.cityId +" job id-->"+$scope.selectedCandidate.originalObject.jobId+" area id-->"+$scope.selectedArea.originalObject.areaId);
		CandidateService.getCandidatesByCriteria($scope.city.cityId, $scope.selectedCandidate.originalObject.jobId, $scope.selectedArea.originalObject.areaId)
		.then(
			function(result) {				
				CandidateService.setCandidateList(result);
				$location.path("/candidateList");			
			},
			function(errResponse){
				alert("Error: No data returned");
			}
		);			
	}
});


/******** Auto complete starts ************/
// https://jsfiddle.net/gumarelo/3qowzjv8/

/*********** select dropdown - start *********************/
// Ref link : http://jsfiddle.net/9Ymvt/880/
