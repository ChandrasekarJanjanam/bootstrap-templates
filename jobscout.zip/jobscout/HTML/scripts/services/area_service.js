'use strict';

jobscoutApp.factory('AreaService', ['$http', '$q', function($http, $q){
 
    return {
         
    fetchAllAreas: function() {
            return $http.get('json/Areas.json')
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while fetching Areas');
                        return $q.reject(errResponse);
                    }
            );
        },
     
	 getAreasByCityId: function(cityId) {
			var url = "";
			if(cityId == 1){
				url = "json/hyderabad.json";
			}else{
				url = "json/guntur.json";
			}
            return $http.get(url)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while fetching Areas');
                        return $q.reject(errResponse);
                    }
            );
        },
     
    createArea: function(Area){
            return $http.post('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/Area/', Area)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while creating Area');
                        return $q.reject(errResponse);
                    }
            );
        },
     
    updateArea: function(Area, id){
            return $http.put('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/Area/'+id, Area)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while updating Area');
                        return $q.reject(errResponse);
                    }
            );
        },
     
   deleteArea: function(id){
            return $http.delete('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/Area/'+id)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while deleting Area');
                        return $q.reject(errResponse);
                    }
            );
        }
         
    };
 
}]);