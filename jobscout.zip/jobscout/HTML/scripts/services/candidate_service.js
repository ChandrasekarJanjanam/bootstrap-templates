'use strict';

jobscoutApp.factory('CandidateService', ['$http', '$q', function($http, $q){
  var candidateList = [];

 
    return {     

		setCandidateList: function(candList) {			
			candidateList = candList;
			console.log("set candidateList-->"+candidateList.length);			  
		},
		
		getCandidateListFromCache: function() {
			console.log("get candidateList.length-->"+candidateList.length);
			 return candidateList;	  
		},
		
		fetchAllCandidates: function() {
            return $http.get('json/candidateList.json')
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while fetching candidateList');
                        return $q.reject(errResponse);
                    }
            );
        },
     
		getCandidatesByCriteria: function(cityId, jobId, areaId) {
			var url = "json/candidateList.json";			
            return $http.get(url)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while fetching Candidates');
                        return $q.reject(errResponse);
                    }
            );
        },
     
		createCandidate: function(Candidate){
            return $http.post('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/Candidate/', Candidate)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while creating Candidate');
                        return $q.reject(errResponse);
                    }
            );
        },
     
		updateCandidate: function(Candidate, id){
            return $http.put('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/Candidate/'+id, Candidate)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while updating Candidate');
                        return $q.reject(errResponse);
                    }
            );
        },
     
		deleteCandidate: function(id){
            return $http.delete('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/Candidate/'+id)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while deleting Candidate');
                        return $q.reject(errResponse);
                    }
            );
        }         
    };
 
}]);