'use strict';
 
jobscoutApp.factory('CityService', ['$http', '$q', function($http, $q){
 
    return {
         
    fetchAllCities: function() {
            return $http.get('json/cities.json')
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while fetching Cities');
                        return $q.reject(errResponse);
                    }
            );
        },
     
	 getCityById: function(id) {
            return $http.get('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/City/'+id)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while fetching Cities');
                        return $q.reject(errResponse);
                    }
            );
        },
     
    createCity: function(City){
            return $http.post('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/City/', City)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while creating City');
                        return $q.reject(errResponse);
                    }
            );
        },
     
    updateCity: function(City, id){
            return $http.put('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/City/'+id, City)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while updating City');
                        return $q.reject(errResponse);
                    }
            );
        },
     
   deleteCity: function(id){
            return $http.delete('http://localhost:8080/Spring4MVCAngularJSNgResourceExample/City/'+id)
            .then(
                    function(response){
                        return response.data;
                    }, 
                    function(errResponse){
                        console.error('Error while deleting City');
                        return $q.reject(errResponse);
                    }
            );
        }
         
    };
 
}]);