jobscoutApp.$inject = ['$scope', 'RefDataService', 'CandidateListService'];

// Used to make ajax calls
jobscoutApp.factory('RefDataService', ['$http','$q',  function($http) {
    
       var factory = {
            getAjaxData: function (url) {  
                console.log(url);
                var data = $http({method: 'GET', url: url});          
                return data;
            }

       }       
        return factory;		
}]);

// All the opertions for Candidate details
jobscoutApp.service('CandidateListService', function() {
  var candidateList = [];

  var addCandidateList = function(newObj) {
      //console.log("newObj-->"+newObj);
	  candidateList = newObj;
	  console.log("candidateList in service-->"+candidateList.length);	  
  };

  var getCandidates = function(){
      return candidateList;
  };

  return {
    addCandidateList: addCandidateList,
    getCandidates: getCandidates
  };

});
